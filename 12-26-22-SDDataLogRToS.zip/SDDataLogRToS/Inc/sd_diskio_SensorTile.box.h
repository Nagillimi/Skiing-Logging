/**
  ******************************************************************************
  * @file    SDDataLogRToS\Inc\sd_diskio_SensorTile.box.h (based on sd_diskio_dma_template.h v2.0.2)
  * @author  SRA - Central Labs
  * @version V1.2.0
  * @date    09-Apr-2020
  * @brief   Header for SDDataLogRToS\Src\sd_diskio_SensorTile.box.c module
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0055, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0055
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __SD_DISKIO_SENSORTILE_BOX_ERRNO_H
#define __SD_DISKIO_SENSORTILE_BOX_ERRNO_H

/* USER CODE BEGIN firstSection */ 
/* can be used to modify / undefine following code or add new definitions */
/* USER CODE END firstSection */

/* Includes ------------------------------------------------------------------*/
#include "SensorTile.box_sd.h"
/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */
extern const Diskio_drvTypeDef  SD_Driver;

/* USER CODE BEGIN lastSection */ 
/* can be used to modify / undefine previous code or add new definitions */
/* USER CODE END lastSection */

#endif /* __SD_DISKIO_SENSORTILE_BOX_ERRNO_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/

