/**
  ******************************************************************************
  * @file    SDDataLogRToS\Inc\TargetFeatures.h 
  * @author  SRA - Central Labs
  * @version V1.2.0
  * @date    09-Apr-2020
  * @brief   Specification of the HW Features for each target platform
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0055, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0055
  *
  ******************************************************************************
  */
  
/* Define to prevent recursive inclusion -------------------------------------*/  
#ifndef _TARGET_FEATURES_H_
#define _TARGET_FEATURES_H_

#ifdef __cplusplus
 extern "C" {
#endif 

/* Includes ------------------------------------------------------------------*/
#include <stdlib.h>
#include <stdio.h>
#include "stm32l4xx_hal.h"

#include "SensorTile.box.h"
#include "SensorTile.box_env_sensors.h"
#include "SensorTile.box_env_sensors_ex.h"
#include "SensorTile.box_motion_sensors.h"
#include "SensorTile.box_motion_sensors_ex.h"
#include "SensorTile.box_audio.h"

/* FatFs includes component */
#include "ff_gen_drv.h"
#include "sd_diskio_SensorTile.box.h"


/* Exported defines ------------------------------------------------------- */
/* Sensor data acquisition period [ms] */
#define DATA_PERIOD_MS     20
#define DATAQUEUE_SIZE     200

#define AUDIO_VOLUME_VALUE       32
#define AUDIO_CHANNELS           1
#define PCM_AUDIO_IN_SAMPLES     (AUDIO_SAMPLING_FREQUENCY / 1000)
#define AUDIO_BUFF_SIZE (PCM_AUDIO_IN_SAMPLES *1024)
#define AUDIO_BUFF_SIZE_MASK (AUDIO_BUFF_SIZE-1)


#define MSG_ENABLE_DISABLE 0x07
#define MSG_AUDIO_SAVE     0x01

/* Sensor parameters */
#define MOTION_MAGNETO_ODR		50.0f
#define MOTION_MAGNETO_FS		50
#define MOTION_ACCELERO_ODR		52.0f
#define MOTION_ACCELERO_FS		16
#define MOTION_GYRO_ODR			52.0f
#define MOTION_GYRO_FS			2000
#define ENV_HUMIDITY_ODR		12.5f
#define ENV_TEMPERATURE_ODR		32.0f
#define ENV_PRESSURE_ODR		50.0f

/* Exported macros ------------------------------------------------------- */
#define MCR_HEART_BIT()  \
{                        \
  BSP_LED_On(LED_BLUE);  \
  BSP_LED_On(LED_GREEN); \
  HAL_Delay(200);        \
  BSP_LED_Off(LED_BLUE); \
  BSP_LED_Off(LED_GREEN);\
  HAL_Delay(400);        \
  BSP_LED_On(LED_BLUE);  \
  BSP_LED_On(LED_GREEN); \
  HAL_Delay(200);        \
  BSP_LED_Off(LED_BLUE); \
  BSP_LED_Off(LED_GREEN);\
  HAL_Delay(1000);       \
}

/* Exported types ------------------------------------------------------- */

/**
 * @brief  Errors type Definitions
 */
typedef enum
{
  STBOX1_NO_ERROR=0,
  STBOX1_INIT_ERROR,
  STBOX1_MEMS_ERROR,
  STBOX1_AUDIO_ERROR,
  STBOX1_FATFS,
  STBOX1_OS,
} ErrorType_t;

/* Exported variables ------------------------------------------------------- */

/* Exported functions ------------------------------------------------------- */
extern void ErrorHanlder(ErrorType_t ErrorType);
extern void InitTargetPlatform(void);
#ifdef __cplusplus
}
#endif

#endif /* _TARGET_FEATURES_H_ */

/******************* (C) COPYRIGHT STMicroelectronics *****END OF FILE****/

