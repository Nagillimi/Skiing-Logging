/**
  ******************** (C) COPYRIGHT STMicroelectronics ***********************
  * @file    readme.txt
  * @author  Central LAB
  * @version V1.2.0
  * @date    09-Apr-2020
  * @brief   Description of the SDDataLog application firmware
  ******************************************************************************
  * Attention
  *
  *                  Copyright (c) 2020 STMicroelectronics.
  *                  All rights reserved.
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0055, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0055
  *
  ******************************************************************************
  */

Application Description 

 This firmware package includes Components Device Drivers, Board Support Package
  and example application for the following STMicroelectronics elements:
  - STEVAL-MKSBOX1V1 (SensorTile.box) evaluation board that contains the following components:
      - MEMS sensor devices: HTS221, LPS22HH, LIS2MDL, LSM6DSOX
      - analog microphone 
  - FatFs generic FAT file system module provides access the storage devices 
   such as memory card and hard disk.
  - FreeRTOS Real Time Kernel/Scheduler that allows applications to be organized as a collection of independent threads of execution
   (under MIT open source license)

 The Example application initializes all the Components and pressing the User button is possible to 
 start/stop the recording off all board's sensors to SD-card.
 The program save 3 different files on SD-card for each log:
 - Sens000.csv where it stores the values of Acc/Gyro/Mag/Pressure/Temperature/Humidity
 - Mic000.wav where it stores the wave file for Analog Microphone at 16Khz
 - Rep000.txt where it stores the summary of used FreeRTOS queues and Max time for writing the Audio Buffer to the .wav file:
 
  Pool Queue:
    Max Size  = XXX
    Released  = XXX
    Allocated = XXX

  Message Queue:
    Max Size  = XXX
    Released  = XXX
    Allocated = XXX
  Max time for writing XXXXbytes for Audio =XXX mSec
 
 
 
@par Hardware and Software environment

  - This example runs on STEVAL-MKSBOX1V1 (SensorTile.box) evaluation board and it
    can be easily tailored to any other supported device and development board.

@par STM32Cube packages:
  - STM32L4xx drivers from STM32CubeL4 V1.15.1
@par STEVAL-MKSBOX1V1:
  - STEVAL-MKSBOX1V1 V1.3.3

@par How to use it ?

This package contains projects for 3 IDEs viz. IAR, �Vision and System Workbench.
In order to make the  program work, you must do the following:
 - WARNING: before opening the project with any toolchain be sure your folder
   installation path is not too in-depth since the toolchain may report errors
   after building.

For IAR:
 - Open IAR toolchain (this firmware has been successfully tested with Embedded Workbench V8.32.3).
 - Open the IAR project file EWARM\DataLog.eww
 - Rebuild all files and Flash the binary on STEVAL-MKSBOX1V1

For �Vision:
 - Open �Vision toolchain (this firmware has been successfully tested with MDK-ARM Professional Version: 5.27.1)
 - Open the �Vision project file MDK-ARM\Project.uvprojx
 - Rebuild all files and Flash the binary on STEVAL-MKSBOX1V1
		
For System STM32CubeIDE:
 Open STM32CubeIDE (this firmware has been successfully tested with Version 1.3.0)
 - Set the default workspace proposed by the IDE (please be sure that there are not spaces in the workspace path).
 - Press "File" -> "Import" -> "Existing Projects into Workspace"; press "Browse" in the "Select root directory" and choose the path where the STM32CubeIDE project is located (it should be STM32CubeIDE\). 
 - Rebuild all files and Flash the binary on STEVAL-MKSBOX1V1
		
 /******************* (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
